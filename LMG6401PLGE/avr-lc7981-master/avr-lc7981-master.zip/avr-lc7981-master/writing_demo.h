/**
 * writing_demo.h
 *
 *  Created on: 29.05.2009
 *      Author: sebastian
 */

#ifndef WIRTING_DEMO_H_
#define WIRTING_DEMO_H_ WIRTING_DEMO_H_

#include <stdlib.h>
#include "include/lc7981.h"
#include "include/adc.h"
#include "include/touch.h"

void writing_demo(void);

#endif
