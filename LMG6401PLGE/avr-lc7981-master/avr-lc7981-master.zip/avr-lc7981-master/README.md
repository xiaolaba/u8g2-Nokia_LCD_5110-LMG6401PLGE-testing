# avr-lc7981
AVR library for the DataVision DG-16080-11

See https://sebastians-site.de/page/Projekte/AVR%20library%20for%20lc7981/ for more info.
